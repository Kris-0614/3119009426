import Util.Compare;

public class Main {
    String[] s = new String[6];
    public String path1 = "C:\\Users\\Deserts\\Desktop\\test\\orig.txt";
    public String path2 = "C:\\Users\\Deserts\\Desktop\\test\\orig_0.8_add.txt";
    public String path3 = "C:\\Users\\Deserts\\Desktop\\test\\orig_0.8_del.txt";
    public String path4 = "C:\\Users\\Deserts\\Desktop\\test\\orig_0.8_dis_1.txt";
    public String path5 = "C:\\Users\\Deserts\\Desktop\\test\\orig_0.8_dis_10.txt";
    public String path6 = "C:\\Users\\Deserts\\Desktop\\test\\orig_0.8_dis_15.txt";
    public void testans() throws Exception {
        System.out.println("第一个文本与第二个文本的重复率：");
        System.out.println(Compare.ans(path1,path2));
    }

    public static void main(String[] args) throws Exception {
        Main main = new Main();
        main.testans();
        Thread.sleep(10000000);
    }
}
