package Util;

@SuppressWarnings("serial")
public class EmptyException extends Exception {
	public EmptyException(String msg) {
		super(msg);
	}
}
